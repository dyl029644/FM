#' Find Maximum Value in Excel File
#'
#' This function reads an Excel file and finds the maximum value in the specified column.
#'
#' @param file_path Path to the Excel file
#' @param sheet Sheet number or name (default: 1)
#' @param column Column name containing the values (default: "value")
#' @param na.rm Logical indicating whether to remove NA values (default: TRUE)
#'
#' @return A list containing:
#'   \item{max_value}{The maximum value found}
#'   \item{column_name}{The name of the column analyzed}
#'   \item{file}{The file path}
#'
#' @examples
#' \dontrun{
#'   # Find maximum value in default column
#'   result <- find_max_value("data.xlsx")
#'
#'   # Find maximum value in specific column
#'   result <- find_max_value("data.xlsx", column = "my_column")
#'
#'   # Use with different sheet
#'   result <- find_max_value("data.xlsx", sheet = 2)
#' }
#'
#' @export
find_max_value <- function(file_path, sheet = 1, column = "value", na.rm = TRUE) {

  # 检查文件是否存在
  if (!file.exists(file_path)) {
    stop("File does not exist: ", file_path)
  }

  # 读取Excel文件
  data <- readxl::read_excel(file_path, sheet = sheet)

  # 检查列是否存在
  if (!column %in% names(data)) {
    available_cols <- paste(names(data), collapse = ", ")
    stop("Column '", column, "' not found. Available columns: ", available_cols)
  }

  # 提取列数据
  column_data <- data[[column]]

  # 确保是数值类型
  if (!is.numeric(column_data)) {
    warning("Column '", column, "' is not numeric. Attempting to convert...")
    column_data <- as.numeric(column_data)
  }

  # 计算最大值
  max_val <- max(column_data, na.rm = na.rm)

  # 创建结果列表
  result <- list(
    max_value = max_val,
    column_name = column,
    file = file_path,
    sheet = sheet,
    data_type = class(column_data)
  )

  # 添加返回值的类
  class(result) <- "excel_max_value"

  return(result)
}

#' Print method for excel_max_value objects
#'
#' @param x An object of class 'excel_max_value'
#' @param ... Additional arguments passed to print
#'
#' @export
print.excel_max_value <- function(x, ...) {
  cat("Excel Maximum Value Analysis\n")
  cat("=============================\n")
  cat("File:", x$file, "\n")
  cat("Sheet:", x$sheet, "\n")
  cat("Column:", x$column_name, "\n")
  cat("Maximum Value:", x$max_value, "\n")
  cat("Data Type:", x$data_type, "\n")
  invisible(x)
}
